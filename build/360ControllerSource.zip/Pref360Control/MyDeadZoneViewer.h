//
//  MyDeadZoneViewer.h
//  360 Driver
//
//  Created by Pierre TACCHI on 21/01/15.
//

#import <Cocoa/Cocoa.h>

@interface MyDeadZoneViewer : NSView

@property (nonatomic) double val;
@property (nonatomic) BOOL linked;

@end
